export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBU-dlwpD1hI0tXOy_bzBvv8thlyGUJ8tY",
    authDomain: "studiology-app.firebaseapp.com",
    databaseURL: "https://studiology-app.firebaseio.com",
    projectId: "studiology-app",
    storageBucket: "studiology-app.appspot.com",
    messagingSenderId: "967084710125"
  };